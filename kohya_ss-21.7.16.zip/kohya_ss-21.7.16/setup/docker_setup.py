from setuptools import setup, find_packages

setup(name="library", version="1.0.3", packages=find_packages())